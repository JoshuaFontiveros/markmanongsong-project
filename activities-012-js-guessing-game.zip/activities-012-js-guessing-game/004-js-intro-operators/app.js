let firstVal = 25;
let secondVal = 5;

console.log('first:' + firstVal);
console.log('second:' + secondVal);
console.log('first + 5 = ' + (firstVal + 5));
secondVal = secondVal + 5;
console.log('second + 5 = ' + secondVal);
console.log('difference: ' + (firstVal - secondVal));
console.log(' product: ' + firstVal * secondVal);
console.log(' quotient: ' + firstVal / secondVal);
console.log('remainder: ' + (firstVal % secondVal));
