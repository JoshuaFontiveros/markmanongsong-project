// generate random any number from 1-20
// keep record of attempts
// check input is lower or higher
// check input is === numberOfTheDay

// Display text: Too High and Too Low
// Reset attempts if exceed
// Mawawala ung number ever submit
// When game over start new session
// Reset button
// reveal secret number pag game over or nanalo
// Confetti
// Add music din (8 bit) pag nanalo

// music
const woWoWin = new Audio("./mp3/wowowin-credits.mp3");

const backGroundMusic = new Audio("./mp3/background-music-playing.mp3");
const epicFailSound = new Audio("./mp3/epic-fail-sound.mp3");

//generateRandomNumber here
const generateRandomNumber = (minimum, maximum) => {
  return Math.floor(Math.random() * maximum - minimum + 1) + minimum;
};

//Modal container
const open = document.getElementById("open");
const modal_container = document.getElementById("modal_container");
const close = document.getElementById("close");

// Modal of Game Over
const openModal = document.getElementById("open");
const closeModal = document.getElementById("close-modal");

const modalContainerGameOver = document.getElementById(
  "modal_container-game-over"
);

console.log(generateRandomNumber(1, 20));

const attempts = [];
const allowedAttempts = 3;
const sessionNumber = generateRandomNumber(1, 20);

const onSubmitHandler = (event) => {
  event.preventDefault();
  const attemptsDiv = document.querySelector(".attempts-counter");

  if (attempts.length >= allowedAttempts) {
    attempts.splice(0, allowedAttempts);
  }

  const attemptsCount = allowedAttempts - attempts.length - 1;
  console.log(attemptsCount);

  if (attemptsCount === 1) {
    openModal.addEventListener("click", () => {
      modalContainerGameOver.classList.add("show");
    });

    closeModal.addEventListener("click", () => {
      location.reload();
    });

    attemptsDiv.innerText = `0 attempts/left`;
  }

  const input = document.getElementById("input-field");
  attempts.push(input.value);

  const indicators = document.querySelector(".indicators");

  const value = Number(input.value);

  attemptsDiv.innerText = `${allowedAttempts - attempts.length} attempt/s left`;

  if (value < 1 || value > 20) {
    alert("Please enter a number between 1 - 20");
    woWoWin.pause();
    woWoWin.currentTime = 0;
  }
  if (value === sessionNumber) {
    open.addEventListener("click", () => {
      modal_container.classList.add("show");
    });
    close.addEventListener("click", () => {
      location.reload();
    });
    console.log(value);
    console.log(sessionNumber);
    indicators.innerText = "Good Job";
    woWoWin.pause();
    woWoWin.currentTime = 0;
    woWoWin.volume = 0.5;
    woWoWin.play();
  }
  if (value > sessionNumber) {
    indicators.innerText = "Too High";
    epicFailSound.pause();
    epicFailSound.currentTime = 0;
    epicFailSound.volume = 0.5;
    epicFailSound.play();
  }
  if (value < sessionNumber) {
    indicators.innerText = "Too Low";
    epicFailSound.pause();
    epicFailSound.currentTime = 0;
    epicFailSound.volume = 0.5;
    epicFailSound.play();
  }
};
// Add game over if exceed the maximum attemp limit
// Add background sounds
